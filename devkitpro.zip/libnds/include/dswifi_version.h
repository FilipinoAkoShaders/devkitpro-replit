#ifndef _dswifi_version_h_
#define _dswifi_version_h_

#define DSWIFI_MAJOR    0
#define DSWIFI_MINOR    4
#define DSWIFI_REVISION 2

#define DSWIFI_VERSION "0.4.2"

#endif // _dswifi_version_h_
