#ifndef __LIBNDSVERSION_H__
#define __LIBNDSVERSION_H__

#define _LIBNDS_MAJOR_	1
#define _LIBNDS_MINOR_	8
#define _LIBNDS_PATCH_	0

#define _LIBNDS_STRING "libNDS Release 1.8.0"

#endif // __LIBNDSVERSION_H__
