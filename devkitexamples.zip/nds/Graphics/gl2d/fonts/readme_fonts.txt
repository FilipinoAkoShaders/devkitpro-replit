This example shows how to make a simple font class in Easy GL2D DS

Fonts by Adigun A. Polack


Relminator (Richard Eric M. Lope)
Http://Rel.Phatcode.Net
November 2010


Note:

This demo works perfectly on a Real DS.

However, if you are running this on an emulator...
No$GBA - works perfectly.
deSmuMe - use the soft rasterizer instead of OpenGL

