This example shows some sprite capabilities of Easy GL2D DS

Also shows how to manage character animation.

Enemies sprites by Adigun A. Polack
Tiles by Unknown
	
Zero sprite by Capcom
Shuttle
	sprite by Patater
Anya Image by Anya Therese B. Lope
Fonts my Marc Russel and Libnds


Relminator (Richard Eric M. Lope)
Http://Rel.Phatcode.Net
November 2010


Note:

This demo works perfectly on a Real DS.

However, if you are running this on an emulator...
No$GBA - works perfectly.
deSmuMe - use the soft rasterizer instead of OpenGL


