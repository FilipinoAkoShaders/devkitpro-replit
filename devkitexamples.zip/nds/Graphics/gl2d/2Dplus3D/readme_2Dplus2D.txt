This example shows how to combine a 3D renderer with Easy GL2D DS

Also shows how to use:
Diferent texture formats
Multiple palettes
Some animation schemes.


Thanks to:
	
Adigun A. Polack for the enemies sprites and 3d Texture
Cearn (Jasper Vijn) for the atan2 implementation 
	
Patater (Jaeden Amero) for the shuttle and flyer sprites


Relminator (Richard Eric M. Lope)
Http://Rel.Phatcode.Net
November 2010


Note:

This demo works perfectly on a Real DS.

However, if you are running this on an emulator...
No$GBA - works perfectly.
deSmuMe - use the soft rasterizer instead of OpenGL


