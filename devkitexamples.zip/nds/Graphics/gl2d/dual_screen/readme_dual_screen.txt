This example shows how to render on both screens with Easy GL2D DS



Relminator (Richard Eric M. Lope)
Http://Rel.Phatcode.Net
November 2010


Note:

This demo works perfectly on a Real DS.

However, if you are running this on an emulator...
No$GBA - works perfectly.
deSmuMe - Lines and Pixels do not show

