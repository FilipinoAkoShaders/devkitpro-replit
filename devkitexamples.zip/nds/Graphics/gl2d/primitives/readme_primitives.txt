This example shows that simple primitives can be nice to look at using Easy GL2D DS


Relminator (Richard Eric M. Lope)
Http://Rel.Phatcode.Net
November 2010


Note:

This demo works perfectly on a Real DS.

However, if you are running this on an emulator...
No$GBA - works perfectly.
deSmuMe - pixels and lines are not rendered.


