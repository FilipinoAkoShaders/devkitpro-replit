This example shows how to do a scrolling engine with Easy GL2D DS

Also shows how to manage character animation.

Tiles by Unknown
	
Crono sprite by Square Enix
	



Relminator (Richard Eric M. Lope)
Http://Rel.Phatcode.Net
November 2010


Note:

This demo works perfectly on a Real DS.

However, if you are running this on an emulator...
No$GBA - works perfectly.
deSmuMe - use the soft rasterizer instead of OpenGL

