Small GP32 demo by Torlus (http://torlus.com) using WinterMute's DevkitARM 
and Mirko's SDK (http://www.mirkoroller.de/)

Some sprites bouncing on screen borders... Well, the only interesting thing
here is the Makefile :) Have a look at it, and see how resources (here, a BMP
file) are automagically converted to object files.
