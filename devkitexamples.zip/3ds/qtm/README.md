# qtm

This is an example for using New3DS QTM for head-tracking.

This is currently not usable from the homebrew launcher.

