# http_post

This is an example for using HTTPC to send a POST request. This sends a request to a site that returns information about your POST request.

