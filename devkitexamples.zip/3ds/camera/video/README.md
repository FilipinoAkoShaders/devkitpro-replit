video
=======

Example for using the camera to capture 3D videos with libctru.

Currently this example does not make use of the 3DS camera's calibration data to get a correct 3D effect.

