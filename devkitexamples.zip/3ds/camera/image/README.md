image
=======

Example for using the camera to take 3D pictures with libctru. Press the R button to take a picture - it will be displayed on the top screen.

Currently this example does not make use of the 3DS camera's calibration data to get a correct 3D effect.

