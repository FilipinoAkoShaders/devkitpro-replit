#pragma once

extern const float vertex_array[7752];
extern const u16 vertex_elements[7392];
#define vertex_element_count 7392
