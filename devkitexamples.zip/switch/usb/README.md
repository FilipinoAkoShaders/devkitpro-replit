# usb

See libnx usb_comms.h. If you want to use usbds directly, see libnx usb_comms.c source and usb.h/usbds.h.

For using USB devices, see the usbhs example.
