# libapplets

These examples show how to launch/use LibraryApplets.

These must be run under an Application with nx-hbloader. Also, note that the last frame displayed by an app prior to launching swkbd will override the frame displayed while NROs are loaded.

