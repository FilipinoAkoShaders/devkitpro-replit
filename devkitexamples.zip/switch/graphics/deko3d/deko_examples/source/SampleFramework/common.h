/*
** Sample Framework for deko3d Applications
**   common.h: Common includes
*/
#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <switch.h>

#include <deko3d.hpp>
