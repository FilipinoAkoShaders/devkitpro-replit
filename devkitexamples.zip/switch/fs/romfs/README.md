# romfs
This example shows how to use RomFS embedded in the application.
